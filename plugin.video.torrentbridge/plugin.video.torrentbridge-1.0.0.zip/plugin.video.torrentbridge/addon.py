import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import sys
import urllib.parse
import requests
import json
import concurrent.futures
import re
import os

# --- CONFIGURACIÓN PRO ---
PROVIDERS = {
    "Torrentio": "https://torrentio.strem.fun/stream/{type}/{id}.json",
    "TPB": "https://apibay.org/q.php?q={id}",
    "Solid": "https://solidtorrents.to/api/v1/search?q={query}"
}

TRACKERS = [
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.torrent.eu.org:451/announce",
    "udp://tracker.moeking.me:6969/announce"
]

SPANISH_KEYWORDS = [r"multi", r"latino", r"spanish", r"español", r"sub", r"dual", r"castellano"]
EXCLUDE_4K = [r"4k", r"2160p", r"uhd", r"ultra hd"]

def log(msg):
    xbmc.log(f"[TorrentBridge-PRO] {msg}", xbmc.LOGINFO)

# --- AUTO INSTALACIÓN DE PLAYER ---

def install_player():
    try:
        # Usar xbmc.translatePath para compatibilidad total (Android/Windows)
        userdata = xbmc.translatePath('special://userdata')
        addon_data = os.path.join(userdata, 'addon_data', 'plugin.video.themoviedb.helper')
        players_path = os.path.join(addon_data, 'players')
        
        if not os.path.exists(players_path):
            os.makedirs(players_path)

        target = os.path.join(players_path, 'TorrentBridge.json')
        
        player_data = {
            "name": "Torrent Bridge",
            "plugin": "plugin.video.torrentbridge",
            "priority": 1,
            "is_resolvable": "false",
            "movies": [{"label": "Play with Torrent Bridge", "command": "RunPlugin(plugin://plugin.video.torrentbridge/?type=movie&imdb={imdb}&title={title}&year={year})", "is_resolvable": "false"}],
            "tvshows": [{"label": "Play with Torrent Bridge", "command": "RunPlugin(plugin://plugin.video.torrentbridge/?type=tv&imdb={imdb}&title={title}&year={year})", "is_resolvable": "false"}],
            "episodes": [{"label": "Play with Torrent Bridge", "command": "RunPlugin(plugin://plugin.video.torrentbridge/?type=episode&imdb={imdb}&title={title}&year={year}&season={season}&episode={episode})", "is_resolvable": "false"}]
        }
        
        with open(target, 'w', encoding='utf-8') as f:
            json.dump(player_data, f, indent=4)
        
        xbmcgui.Dialog().notification("Torrent Bridge", "Puente TMDB Instalado con Exito", xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    except Exception as e:
        log(f"Error en instalacion: {str(e)}")
        return False

# --- MOTORES ---

def inject_trackers(magnet):
    if not magnet.startswith("magnet:"): return magnet
    for tr in TRACKERS:
        if tr not in magnet: magnet += f"&tr={urllib.parse.quote_plus(tr)}"
    return magnet

def check_spanish(text):
    text = text.lower()
    return any(re.search(kw, text) for kw in SPANISH_KEYWORDS)

def is_4k(text):
    text = text.lower()
    return any(re.search(kw, text) for kw in EXCLUDE_4K)

def search_solid(query):
    try:
        resp = requests.get(PROVIDERS["Solid"].format(query=urllib.parse.quote_plus(query)), timeout=6)
        if resp.status_code == 200:
            results = resp.json().get("results", [])
            return [{"name": r['title'], "label": f"[COLOR orange]Solid[/COLOR] | {r['title']}", "magnet": inject_trackers(f"magnet:?xt=urn:btih:{r['infohash']}"), "seeds": int(r['seeders']), "spanish": check_spanish(r['title'])} for r in results if not is_4k(r['title'])]
    except: pass
    return []

def search_tpb(item_id):
    try:
        resp = requests.get(PROVIDERS["TPB"].format(id=item_id), timeout=6)
        if resp.status_code == 200:
            data = resp.json()
            if not isinstance(data, list): return []
            return [{"name": i['name'], "label": f"[COLOR blue]TPB[/COLOR] | {i['name']}", "magnet": inject_trackers(f"magnet:?xt=urn:btih:{i['info_hash']}"), "seeds": int(i['seeders']), "spanish": check_spanish(i['name'])} for i in data if i.get("id") != "0" and not is_4k(i['name'])]
    except: pass
    return []

def search_stremio(item_type, item_id):
    try:
        resp = requests.get(PROVIDERS["Torrentio"].format(type=item_type, id=item_id), timeout=6)
        if resp.status_code == 200:
            streams = resp.json().get("streams", [])
            out = []
            for s in streams:
                full_text = f"{s.get('name')} {s.get('title')}"
                if is_4k(full_text): continue
                seeds = 0
                match = re.search(r'(?:👤|Seeders:)\s*(\d+)', full_text)
                if match: seeds = int(match.group(1))
                magnet = f"magnet:?xt=urn:btih:{s['infoHash']}" if s.get('infoHash') else s.get('url')
                if not magnet: continue
                out.append({"name": s.get('name'), "label": f"[COLOR green]Torrentio[/COLOR] | {s.get('name').replace('Torrentio','').strip()}", "magnet": inject_trackers(magnet), "seeds": seeds, "spanish": check_spanish(full_text)})
            return out
    except: pass
    return []

# --- CORE ---

def run():
    params = urllib.parse.parse_qs(sys.argv[2][1:])
    media_type = params.get("type", ["movie"])[0]
    imdb_id = params.get("imdb", [""])[0]
    title = params.get("title", [""])[0]
    year = params.get("year", [""])[0]

    # Siempre intentar instalar el player al abrir
    install_player()

    if not imdb_id:
        xbmcgui.Dialog().ok("Torrent Bridge PRO", "Configuracion completada.\nUsa TMDB Helper para buscar peliculas.")
        return

    progress = xbmcgui.DialogProgress()
    progress.create("Buscando Torrent...", "Iniciando motores PRO...")

    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        f1 = executor.submit(search_stremio, media_type, imdb_id)
        f2 = executor.submit(search_tpb, imdb_id)
        query = f"{title} {year}" if title else imdb_id
        f3 = executor.submit(search_solid, query)
        
        progress.update(40, f"Consultando fuentes para: {query}")
        results.extend(f1.result() or [])
        results.extend(f2.result() or [])
        results.extend(f3.result() or [])

    progress.update(90, "Deduplicando enlaces...")
    unique = {}
    for r in results:
        hid = r['magnet'].split('&')[0].lower()
        if hid not in unique or r['seeds'] > unique[hid]['seeds']: unique[hid] = r
    
    final = sorted(unique.values(), key=lambda x: (x['spanish'], x['seeds']), reverse=True)
    progress.close()

    if not final:
        xbmcgui.Dialog().ok("Error", "No se encontraron fuentes PRO para esta pelicula.")
        return

    labels = [f"{'[COLOR yellow][MULTI/ESP][/COLOR] ' if r['spanish'] else ''}{r['label']} ({r['seeds']} seeds)" for r in final]
    selected = xbmcgui.Dialog().select("Fuentes Disponibles (1080p/720p)", labels)
    
    if selected != -1:
        xbmc.executebuiltin(f"PlayMedia(plugin://plugin.video.elementum/play?uri={urllib.parse.quote_plus(final[selected]['magnet'])})")

if __name__ == "__main__":
    run()
