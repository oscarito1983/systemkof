import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
import sys
import urllib.parse
import requests
import json
import concurrent.futures
import re
import os

# --- CONFIGURACIÓN ---
PROVIDERS = {
    "Torrentio": "https://torrentio.strem.fun/stream/{type}/{id}.json",
    "TPB":       "https://apibay.org/q.php?q={query}",
    "Solid":     "https://solidtorrents.to/api/v1/search?q={query}"
}

TRACKERS = [
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.torrent.eu.org:451/announce",
    "udp://tracker.moeking.me:6969/announce"
]

SPANISH_KEYWORDS = [r"multi", r"latino", r"spanish", r"espa.ol", r"\bsub\b", r"dual", r"castellano"]
EXCLUDE_4K       = [r"4k", r"2160p", r"\buhd\b", r"ultra.?hd"]

def log(msg):
    xbmc.log(f"[TorrentBridge] {msg}", xbmc.LOGINFO)

# ─────────────────────────────────────────────
# AUTO-INSTALACIÓN DEL PLAYER (solo primera vez)
# ─────────────────────────────────────────────
def install_player():
    try:
        # FIX #1: xbmcvfs.translatePath (Kodi 19+ Matrix/Nexus)
        userdata    = xbmcvfs.translatePath("special://userdata")
        players_dir = os.path.join(userdata, "addon_data",
                                   "plugin.video.themoviedb.helper", "players")
        os.makedirs(players_dir, exist_ok=True)

        target = os.path.join(players_dir, "TorrentBridge.json")

        # FIX #4: is_resolvable como booleano, NO como string
        player_data = {
            "name":          "Torrent Bridge",
            "plugin":        "plugin.video.torrentbridge",
            "priority":      1,
            "is_resolvable": False,
            "movies": [{
                "label":         "▶ Play with Torrent Bridge (Free)",
                "command":       "RunPlugin(plugin://plugin.video.torrentbridge/?type=movie&imdb={imdb}&title={title}&year={year})",
                "is_resolvable": False
            }],
            "tvshows": [{
                "label":         "▶ Play with Torrent Bridge (Free)",
                "command":       "RunPlugin(plugin://plugin.video.torrentbridge/?type=tv&imdb={imdb}&title={title}&year={year})",
                "is_resolvable": False
            }],
            "episodes": [{
                "label":         "▶ Play with Torrent Bridge (Free)",
                "command":       "RunPlugin(plugin://plugin.video.torrentbridge/?type=episode&imdb={imdb}&title={title}&year={year}&season={season}&episode={episode})",
                "is_resolvable": False
            }]
        }

        with open(target, "w", encoding="utf-8") as f:
            json.dump(player_data, f, indent=4)

        log(f"Player instalado en: {target}")
        xbmcgui.Dialog().notification(
            "Torrent Bridge",
            "✅ Player instalado en TMDB Helper",
            xbmcgui.NOTIFICATION_INFO, 4000
        )
        return True
    except Exception as e:
        log(f"Error instalando player: {e}")
        xbmcgui.Dialog().notification(
            "Torrent Bridge",
            f"⚠ Error al instalar player: {e}",
            xbmcgui.NOTIFICATION_WARNING, 5000
        )
        return False

# ─────────────────────────────────────────────
# UTILIDADES
# ─────────────────────────────────────────────
def inject_trackers(magnet):
    if not magnet.startswith("magnet:"):
        return magnet
    for tr in TRACKERS:
        if tr not in magnet:
            magnet += f"&tr={urllib.parse.quote_plus(tr)}"
    return magnet

def check_spanish(text):
    t = text.lower()
    return any(re.search(kw, t) for kw in SPANISH_KEYWORDS)

def is_4k(text):
    t = text.lower()
    return any(re.search(kw, t) for kw in EXCLUDE_4K)

def build_result(source_color, source_name, name, magnet, seeds):
    return {
        "name":    name,
        "label":   f"[COLOR {source_color}][{source_name}][/COLOR] {name}",
        "magnet":  inject_trackers(magnet),
        "seeds":   seeds,
        "spanish": check_spanish(name)
    }

# ─────────────────────────────────────────────
# MOTORES DE BÚSQUEDA
# ─────────────────────────────────────────────

def search_torrentio(media_type, imdb_id, season=None, episode=None):
    """
    FIX #2: Para episodios usa formato series/tt...:S:E
    """
    try:
        if media_type == "episode" and season and episode:
            stremio_type = "series"
            stremio_id   = f"{imdb_id}:{season}:{episode}"
        elif media_type in ("tv", "series"):
            stremio_type = "series"
            stremio_id   = imdb_id
        else:
            stremio_type = "movie"
            stremio_id   = imdb_id

        url  = PROVIDERS["Torrentio"].format(type=stremio_type, id=stremio_id)
        resp = requests.get(url, timeout=8)
        if resp.status_code != 200:
            return []

        streams = resp.json().get("streams", [])
        out = []
        for s in streams:
            full_text = f"{s.get('name', '')} {s.get('title', '')}"
            if is_4k(full_text):
                continue
            seeds = 0
            m = re.search(r"(?:👤|Seeders:)\s*(\d+)", full_text)
            if m:
                seeds = int(m.group(1))
            info_hash = s.get("infoHash")
            if not info_hash:
                continue
            magnet = f"magnet:?xt=urn:btih:{info_hash}"
            name   = s.get("name", "").replace("Torrentio", "").strip()
            out.append(build_result("green", "Torrentio", name, magnet, seeds))
        return out
    except Exception as e:
        log(f"Torrentio error: {e}")
        return []


def search_tpb(query):
    """
    FIX #3: Busca por TÍTULO, no por IMDB ID
    """
    try:
        url  = PROVIDERS["TPB"].format(query=urllib.parse.quote_plus(query))
        resp = requests.get(url, timeout=8)
        if resp.status_code != 200:
            return []
        data = resp.json()
        if not isinstance(data, list):
            return []
        out = []
        for i in data:
            if str(i.get("id", "0")) == "0":
                continue
            name = i.get("name", "")
            if is_4k(name):
                continue
            magnet = f"magnet:?xt=urn:btih:{i['info_hash']}"
            seeds  = int(i.get("seeders", 0))
            out.append(build_result("blue", "TPB", name, magnet, seeds))
        return out
    except Exception as e:
        log(f"TPB error: {e}")
        return []


def search_solid(query):
    try:
        url  = PROVIDERS["Solid"].format(query=urllib.parse.quote_plus(query))
        resp = requests.get(url, timeout=8)
        if resp.status_code != 200:
            return []
        results = resp.json().get("results", [])
        out = []
        for r in results:
            name = r.get("title", "")
            if is_4k(name):
                continue
            magnet = f"magnet:?xt=urn:btih:{r['infohash']}"
            seeds  = int(r.get("seeders", 0))
            out.append(build_result("orange", "Solid", name, magnet, seeds))
        return out
    except Exception as e:
        log(f"Solid error: {e}")
        return []

# ─────────────────────────────────────────────
# CORE
# ─────────────────────────────────────────────

def run():
    raw_params  = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    params      = urllib.parse.parse_qs(raw_params)

    media_type  = params.get("type",    ["movie"])[0]
    imdb_id     = params.get("imdb",    [""])[0]
    title       = params.get("title",   [""])[0]
    year        = params.get("year",    [""])[0]
    # FIX #2: leer season y episode
    season      = params.get("season",  [""])[0]
    episode     = params.get("episode", [""])[0]

    # FIX #5: instalar player solo cuando se abre el addon directamente (sin params)
    if not imdb_id:
        if install_player():
            xbmcgui.Dialog().ok(
                "Torrent Bridge",
                "✅ Configuración completada.\n\n"
                "El player ha sido instalado en TMDB Helper.\n"
                "Ahora busca una película o serie desde TMDB Helper\n"
                "y elige [▶ Play with Torrent Bridge] como reproductor."
            )
        return

    # Construir query legible para TPB y Solid
    if media_type == "episode" and season and episode:
        s_num = season.zfill(2)
        e_num = episode.zfill(2)
        search_query = f"{title} S{s_num}E{e_num}"
        display_name = f"{title} S{s_num}E{e_num}"
    elif title:
        search_query = f"{title} {year}".strip()
        display_name = search_query
    else:
        search_query = imdb_id
        display_name = imdb_id

    log(f"Buscando: type={media_type} imdb={imdb_id} query={search_query}")

    progress = xbmcgui.DialogProgress()
    progress.create("🔍 Torrent Bridge", f"Buscando: {display_name}")

    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        f1 = executor.submit(search_torrentio, media_type, imdb_id, season, episode)
        f2 = executor.submit(search_tpb,      search_query)
        f3 = executor.submit(search_solid,    search_query)

        progress.update(30, "Consultando Torrentio...")
        r1 = f1.result() or []
        progress.update(60, "Consultando TPB...")
        r2 = f2.result() or []
        progress.update(85, "Consultando SolidTorrents...")
        r3 = f3.result() or []

    results = r1 + r2 + r3
    progress.update(95, "Procesando resultados...")

    # Deduplicar por info_hash, quedarse con más seeds
    unique = {}
    for r in results:
        hid = r["magnet"].split("&")[0].lower()
        if hid not in unique or r["seeds"] > unique[hid]["seeds"]:
            unique[hid] = r

    # Ordenar: español primero, luego por seeds
    final = sorted(unique.values(),
                   key=lambda x: (x["spanish"], x["seeds"]),
                   reverse=True)
    progress.close()

    if not final:
        xbmcgui.Dialog().ok(
            "Torrent Bridge",
            f"No se encontraron fuentes para:\n{display_name}\n\n"
            "Prueba con otro título o verifica tu conexión."
        )
        return

    # Mostrar lista de fuentes
    labels = []
    for r in final:
        esp_tag = "[COLOR yellow][ESP/MULTI][/COLOR] " if r["spanish"] else ""
        labels.append(f"{esp_tag}{r['label']}  ({r['seeds']} seeds)")

    selected = xbmcgui.Dialog().select(
        f"Fuentes para: {display_name}  ({len(final)} encontradas)",
        labels
    )

    if selected >= 0:
        magnet_enc = urllib.parse.quote_plus(final[selected]["magnet"])
        elementum_url = f"plugin://plugin.video.elementum/play?uri={magnet_enc}"
        log(f"Reproduciendo: {elementum_url[:80]}...")
        xbmc.executebuiltin(f"PlayMedia({elementum_url})")


if __name__ == "__main__":
    run()
